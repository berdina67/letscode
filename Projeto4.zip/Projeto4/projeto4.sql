CREATE TABLE aluno(
		cpf VARCHAR(11) NOT NULL,
		nome VARCHAR(25) NOT NULL,
		endereco VARCHAR(50) NOT NULL,
		telefone VARCHAR(15),
		data_nascimento DATE,
		PRIMARY KEY (cpf));
		
CREATE TABLE matricula(
		id INTEGER PRIMARY KEY AUTO_INCREMENT,		
		cpf_aluno VARCHAR(11),
		id_curso INTEGER
		);

CREATE TABLE curso(
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nome VARCHAR(25) NOT NULL,
		descricao VARCHAR(50)
		);
		
CREATE TABLE cursa(
		cpf_aluno VARCHAR(11) NOT NULL,
		id_disciplina INTEGER
		);
					
CREATE TABLE disciplina(
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nome VARCHAR(25) NOT NULL,
		);
		
CREATE TABLE compoe(
		id_curso INTEGER,
		id_disciplina INTEGER
		);

CREATE TABLE departamento(
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nome VARCHAR(25)
		);
		
CREATE TABLE contrata(
		id INTEGER NOT NULL AUTO_INCREMENT,
		id_professor INTEGER,
		id_departamento INTEGER,
		data_contratacao DATE,
		PRIMARY KEY(id)
		);

CREATE TABLE professor(
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nome VARCHAR(25) NOT NULL,
		endereco VARCHAR(50),
		telefone VARCHAR(15),
		data_nascimento date,
		data_contatacao date
		);
		
CREATE TABLE leciona(
		id_professor INTEGER,
		id_disciplina INTEGER
		);

CREATE TABLE pre_requisito(
		id_dependencia integer,
		id_disciplina INTEGER
		);
		
CREATE TABLE controla(
		id_curso INTEGER,
		id_departamento INTEGER
		);

alter table pre_requisito add primary key(id_dependencia, id_disciplina);

-- Cadastro de chaves estrangeiras.

-- aluno > matricula < curso
alter table matricula ADD constraint foreign key(cpf_aluno) references aluno(cpf); 
alter table matricula ADD constraint foreign key(id_curso) references curso(id);

-- aluno > cursa < disciplina
alter table cursa ADD constraint foreign key(cpf_aluno) references aluno(cpf);
alter table cursa ADD constraint foreign key(id_disciplina) references disciplina(id);

-- curso > controla < departamento
alter table controla ADD constraint foreign key(id_curso) references curso(id);
alter table controla ADD constraint foreign key(id_departamento) references departamento(id);

-- curso > compõe < disciplina
alter table compoe ADD constraint foreign key(id_curso) references curso(id); 
alter table compoe ADD constraint foreign key(id_disciplina) references disciplina(id);

-- departamento > contrata < professor
alter table contrata ADD constraint foreign key(id_departamento) references departamento(id); 
alter table contrata ADD constraint foreign key(id_professor) references professor(id);

-- disciplina > leciona < professor
alter table leciona ADD constraint foreign key(id_disciplina) references disciplina(id); 
alter table leciona ADD constraint foreign key(id_professor) references professor(id);

-- Inserçação de valores por linha de coamando:
insert into departamento(id, nome) 
values
(default, 'Ciências Humanas'),
(default, 'Ciências Exatas'),
(default, 'Ciências Biológicas');

insert into curso(id, nome, descricao) values(default, 'medicina', default); -- restante importado pelo arquivo curso.csv
insert into disciplina(id, nome) values(default, 'anatomia'); -- restante importado pelo arquivo disciplina.csv

insert 
into controla(id_curso, id_departamento) 
values (1,3),(2,3),(3,3),(4,3),(5,1),(6,1),(7,1),(8,1),(9,2),(10,2),(11,2),(12,2),(13,2);

insert 
into matricula(cpf_aluno, id_curso)
values
('11111111111',12),
('11111222222',11),
('11111333333',11),
('11111444444',12),
('11111555555',4),
('11111666666',13),
('11111777777',6),
('11111888888',3),
('11111999999',3),
('11112111110',4),
('11122222210',4),
('11112333332',3);

-- O restante foi inserido através da ferramenta Table Data Export Wizard do Workbench conforme tabelas em csv em anexo.

-- Apresentação das tabelas  através do SELECT
-- Filtragem usando o INNER JOIN
-- tabela 1 - Aluno > matricula < curso

/*
mysql> use escola;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

1. Produza um relatório que contenha os dados dos alunos matriculados em todos os cursos oferecidos pela escola.

Database changed
mysql> select a.cpf, a.nome, c.nome as curso
    -> from matricula as m
    -> inner join aluno as a
    -> on a.cpf = m.cpf_aluno
    -> inner join curso as c
    -> on c.id = m.id_curso;
+-------------+-----------+----------------------------+
| cpf         | nome      | curso                       |
+-------------+-----------+----------------------------+
| 11111111111 | ADRIANA   | Engenharia da Computação   |
| 11111222222 | ADRIANO   | Engenharia Elétrica        |
| 11111333333 | AGNALDO   | Engenharia Elétrica        |
| 11111444444 | AIRTON    | Engenharia da Computação   |
| 11111555555 | BRUNO     | Farmácia                   |
| 11111666666 | CAMILA    | Ciência da Computação      |
| 11111777777 | CARLOS    | Direito                    |
| 11111888888 | CELSO     | Odontologia                |
| 11111999999 | DANIEL    | Odontologia                |
| 11112111110 | DANIELA   | Farmácia                   |
| 11122222210 | DIEGO     | Farmácia                   |
| 11112333332 | EDIMILSON | Odontologia                |
+-------------+-----------+----------------------------+
12 rows in set (0,00 sec)

mysql> 

b. Produza um relatório com os dados de todos os cursos, com suas respectivas disciplinas, oferecidos pela escola.
select c.nome as curso, c.id, d.nome as disciplina, d.id
    from compoe as cp
    inner join disciplina as d
    on d.id = cp.id_disciplina 
    inner join curso as c
    on c.id = cp.id_curso;

+----------------------------+----+------------------------------+----+
| curso                      | id | disciplina                   | id |
+----------------------------+----+------------------------------+----+
| Fisioterapia               |  1 | anatomia                     |  1 |
| Medicina                   |  2 | Fisiologia                   |  2 |
| Odontologia                |  3 | Biologia celular             |  3 |
| Odontologia                |  3 | Dentística                   |  4 |
| Odontologia                |  3 | Endodontia                   |  5 |
| Odontologia                |  3 | Periodontia                  |  6 |
| Psicologia                 |  5 | Psicologia Social            |  7 |
| Psicologia                 |  5 | Psicopatologia               |  8 |
| Psicologia                 |  5 | Neuropsicologia              |  9 |
| Direito                    |  6 | Antropologia                 | 10 |
| Direito                    |  6 | Direito Romano               | 11 |
| Direito                    |  6 | Direito Civil                | 12 |
| Direito                    |  6 | Direito Constitucional       | 13 |
| Administração              |  7 | TGA                          | 19 |
| Administração              |  7 | RH1                          | 20 |
| Administração              |  7 | RH2                          | 21 |
| Administração              |  7 | Administração financeira     | 22 |
| Administração              |  7 | Marketing                    | 23 |
| Administração              |  7 | Planejamento Estratégico     | 24 |
| Administração              |  7 | Estatística                  | 30 |
| Economia                   |  8 | Sociologia                   | 14 |
| Economia                   |  8 | Macroeconomia                | 15 |
| Economia                   |  8 | Microeconomia                | 16 |
| Economia                   |  8 | Contabilidade                | 17 |
| Economia                   |  8 | Econometria                  | 18 |
| Matemática                 |  9 | Pré-calculo                  | 25 |
| Matemática                 |  9 | Cálculo I                    | 26 |
| Matemática                 |  9 | Cálculo II                   | 27 |
| Matemática                 |  9 | Lógica                       | 28 |
| Matemática                 |  9 | Álgebra                      | 29 |
| Física                     | 10 | Álgebra Linear               | 31 |
| Física                     | 10 | Física Experimental          | 32 |
| Física                     | 10 | Física I                     | 33 |
| Física                     | 10 | Física II                    | 34 |
| Física                     | 10 | Geometria Analítica          | 35 |
| Engenharia Elétrica        | 11 | Circuitos Elétricos          | 36 |
| Engenharia Elétrica        | 11 | Eletromagnetismo             | 37 |
| Engenharia da Computação   | 12 | Eletrônica Digital           | 38 |
| Engenharia da Computação   | 12 | Linguagem de Programação     | 43 |
| Engenharia da Computação   | 12 | Robótica                     | 44 |
| Engenharia da Computação   | 12 | Sistemas Operacionais        | 45 |
| Engenharia da Computação   | 12 | Introdução à computação      | 46 |
| Engenharia da Computação   | 12 | Programação em Assembly      | 47 |
| Engenharia da Computação   | 12 | Arquitetura de computer      | 48 |
| Ciência da Computação      | 13 | Algoritmos                   | 39 |
| Ciência da Computação      | 13 | BD I                         | 40 |
| Ciência da Computação      | 13 | BD II                        | 41 |
| Ciência da Computação      | 13 | Lógica de Programação        | 42 |
+----------------------------+----+------------------------------+----+
48 rows in set (0,00 sec)

mysql> 

c. Produza um relatório que contenha o nome dos alunos e as disciplinas em que estão matriculados.

mysql> select a.cpf, a.nome, d.nome as disciplina
    -> from cursa as cs
    -> inner join aluno as a
    -> on a.cpf = cs.cpf_aluno
    -> inner join disciplina as d
    -> on d.id = cs.id_disciplina;
+-------------+-----------+------------------------------+
| cpf         | nome      | disciplina                   |
+-------------+-----------+------------------------------+
| 11111111111 | ADRIANA   | Psicologia Social            |
| 11111111111 | ADRIANA   | Psicopatologia               |
| 11111111111 | ADRIANA   | Neuropsicologia              |
| 11111222222 | ADRIANO   | Periodontia                  |
| 11111222222 | ADRIANO   | Antropologia                 |
| 11111222222 | ADRIANO   | Direito Romano               |
| 11111222222 | ADRIANO   | Direito Civil                |
| 11111222222 | ADRIANO   | Direito Constitucional       |
| 11111333333 | AGNALDO   | Sociologia                   |
| 11111333333 | AGNALDO   | Macroeconomia                |
| 11111333333 | AGNALDO   | Microeconomia                |
| 11111333333 | AGNALDO   | Contabilidade                |
| 11111444444 | AIRTON    | Econometria                  |
| 11111444444 | AIRTON    | TGA                          |
| 11111444444 | AIRTON    | RH1                          |
| 11111444444 | AIRTON    | RH2                          |
| 11111444444 | AIRTON    | Administração financeira     |
| 11111444444 | AIRTON    | Marketing                    |
| 11111555555 | BRUNO     | Planejamento Estratégico     |
| 11111555555 | BRUNO     | Pré-calculo                  |
| 11111555555 | BRUNO     | Cálculo I                    |
| 11111555555 | BRUNO     | Cálculo II                   |
| 11111555555 | BRUNO     | Lógica                       |
| 11111555555 | BRUNO     | Álgebra                      |
| 11111666666 | CAMILA    | anatomia                     |
| 11111666666 | CAMILA    | Fisiologia                   |
| 11111666666 | CAMILA    | Biologia celular             |
| 11111666666 | CAMILA    | Dentística                   |
| 11111666666 | CAMILA    | Endodontia                   |
| 11111666666 | CAMILA    | Estatística                  |
| 11111666666 | CAMILA    | Álgebra Linear               |
| 11111666666 | CAMILA    | Física Experimental          |
| 11111666666 | CAMILA    | Física I                     |
| 11111666666 | CAMILA    | Física II                    |
| 11111777777 | CARLOS    | Geometria Analítica          |
| 11111777777 | CARLOS    | Circuitos Elétricos          |
| 11111777777 | CARLOS    | Eletromagnetismo             |
| 11111888888 | CELSO     | Eletrônica Digital           |
| 11111888888 | CELSO     | Algoritmos                   |
| 11111888888 | CELSO     | BD I                         |
| 11111888888 | CELSO     | BD II                        |
| 11111888888 | CELSO     | Lógica de Programação        |
| 11111999999 | DANIEL    | Linguagem de Programação     |
| 11111999999 | DANIEL    | Robótica                     |
| 11111999999 | DANIEL    | Sistemas Operacionais        |
| 11111999999 | DANIEL    | Introdução à computação      |
| 11111999999 | DANIEL    | Programação em Assembly      |
| 11112111110 | DANIELA   | Econometria                  |
| 11112111110 | DANIELA   | TGA                          |
| 11112111110 | DANIELA   | RH1                          |
| 11112111110 | DANIELA   | RH2                          |
| 11112111110 | DANIELA   | Administração financeira     |
| 11112111110 | DANIELA   | Marketing                    |
| 11112333332 | EDIMILSON | Psicologia Social            |
| 11112333332 | EDIMILSON | Psicopatologia               |
| 11112333332 | EDIMILSON | Neuropsicologia              |
| 11122222210 | DIEGO     | Estatística                  |
| 11122222210 | DIEGO     | Álgebra Linear               |
| 11122222210 | DIEGO     | Física Experimental          |
| 11122222210 | DIEGO     | Física I                     |
| 11122222210 | DIEGO     | Física II                    |
+-------------+-----------+------------------------------+
61 rows in set (0,00 sec)

mysql> 

d. Produza um relatório com os dados dos professores e as disciplinas que ministram.

mysql> select p.nome as professor, d.nome as disciplina
    ->     from leciona as l
    ->     inner join disciplina as d
    ->     on d.id = l.id_disciplina 
    ->     inner join professor as p
    ->     on p.id = l.id_professor;
+-------------+------------------------------+
| professor   | disciplina                   |
+-------------+------------------------------+
| ALEXANDRE   | anatomia                     |
| ALEXANDRE   | Fisiologia                   |
| ALEXANDRE   | Biologia celular             |
| MARA        | Dentística                   |
| MARA        | Endodontia                   |
| MARA        | Periodontia                  |
| ELISA       | Psicologia Social            |
| ELISA       | Psicopatologia               |
| ELISA       | Neuropsicologia              |
| ELISA       | Antropologia                 |
| ROGERIO     | Direito Romano               |
| ROGERIO     | Direito Civil                |
| ROGERIO     | Direito Constitucional       |
| ROGERIO     | Sociologia                   |
| JESSICA     | Macroeconomia                |
| JESSICA     | Microeconomia                |
| JESSICA     | Contabilidade                |
| JESSICA     | Econometria                  |
| JOAO CARLOS | TGA                          |
| JOAO CARLOS | RH1                          |
| JOAO CARLOS | RH2                          |
| JOAO CARLOS | Administração financeira     |
| JOAO CARLOS | Marketing                    |
| JOAO CARLOS | Planejamento Estratégico     |
| ALBERTO     | Pré-calculo                  |
| ALBERTO     | Cálculo I                    |
| ALBERTO     | Cálculo II                   |
| ALBERTO     | Lógica                       |
| ALBERTO     | Álgebra                      |
| ALBERTO     | Estatística                  |
| CIRLENE     | Álgebra Linear               |
| CIRLENE     | Física Experimental          |
| CIRLENE     | Física I                     |
| CIRLENE     | Física II                    |
| CIRLENE     | Geometria Analítica          |
| FATIMA      | Circuitos Elétricos          |
| FATIMA      | Eletromagnetismo             |
| FATIMA      | Eletrônica Digital           |
| MATHEUS     | Algoritmos                   |
| MATHEUS     | BD I                         |
| MATHEUS     | BD II                        |
| MATHEUS     | Lógica de Programação        |
| PAULO       | Lógica de Programação        |
| PAULO       | Linguagem de Programação     |
| PAULO       | Robótica                     |
| LILIANE     | Sistemas Operacionais        |
| REGIANE     | Introdução à computação      |
| DANILO      | Programação em Assembly      |
| CARLOS      | Programação em Assembly      |
+-------------+------------------------------+
49 rows in set (0,00 sec)

mysql> 

e. Produza um relatório com os nomes das disciplinas e seus pré-requisitos.

mysql> select distinct d.nome as discipliplina, dis.nome as prerequisito
    -> from disciplina as d
    -> inner join pre_requisito as pr
    -> on d.id = pr.id_disciplina
    -> inner join disciplina as dis
    -> on dis.id = pr.id_pre_requisito;  
+----------------------------+--------------------------+
| discipliplina              | prerequisito             |
+----------------------------+--------------------------+
| Dentística                 | Biologia celular         |
| Endodontia                 | Biologia celular         |
| Endodontia                 | Dentística               |
| Periodontia                | Biologia celular         |
| Periodontia                | Dentística               |
| Psicopatologia             | Psicologia Social        |
| Neuropsicologia            | Psicologia Social        |
| Neuropsicologia            | Psicopatologia           |
| Direito Civil              | Direito Romano           |
| Direito Constitucional     | Direito Romano           |
| RH2                        | RH1                      |
| Planejamento Estratégico   | TGA                      |
| Cálculo I                  | Pré-calculo              |
| Cálculo II                 | Pré-calculo              |
| Eletromagnetismo           | Cálculo I                |
| Álgebra Linear             | Álgebra                  |
| Física I                   | Física Experimental      |
| Física II                  | Física Experimental      |
| Física II                  | Física I                 |
| Eletrônica Digital         | Circuitos Elétricos      |
| BD II                      | BD I                     |
| Linguagem de Programação   | Algoritmos               |
| Lógica de Programação      | Algoritmos               |
| Linguagem de Programação   | Lógica de Programação    |
+----------------------------+--------------------------+
24 rows in set (0,01 sec)

mysql> 

f. Produza um relatório com a média de idade dos alunos matriculados em cada curso.

mysql> select avg(TIMESTAMPDIFF(year,data_nascimento,now())) as 'media de idade', 
    -> count('cpf') as matriculados
    ->     from aluno as a
    ->     inner join matricula as m
    ->     on a.cpf = m.cpf_aluno
    ->     inner join curso as c
    ->     on c.id = m.id_curso;
+----------------+--------------+
| media de idade | matriculados |
+----------------+--------------+
|        36.5833 |           12 |
+----------------+--------------+
1 row in set (0,00 sec)

mysql>

g. Produza um relatório com os cursos oferecidos por cada departamento.

mysql> describe curso;
+-----------+-------------+------+-----+---------+----------------+
| Field     | Type        | Null | Key | Default | Extra          |
+-----------+-------------+------+-----+---------+----------------+
| id        | int         | NO   | PRI | NULL    | auto_increment |
| nome      | varchar(25) | NO   |     | NULL    |                |
| descricao | varchar(50) | YES  |     | NULL    |                |
+-----------+-------------+------+-----+---------+----------------+
3 rows in set (0,02 sec)

mysql> alter table curso ADD(id_departamento integer);
Query OK, 0 rows affected (3,51 sec)
Records: 0  Duplicates: 0  Warnings: 0

mysql> alter table curso ADD constraint foreign key(id_departamento) references departamento(id);
Query OK, 13 rows affected (3,14 sec)
Records: 13  Duplicates: 0  Warnings: 0

mysql> describe curso;
+-----------------+-------------+------+-----+---------+----------------+
| Field           | Type        | Null | Key | Default | Extra          |
+-----------------+-------------+------+-----+---------+----------------+
| id              | int         | NO   | PRI | NULL    | auto_increment |
| nome            | varchar(25) | NO   |     | NULL    |                |
| descricao       | varchar(50) | YES  |     | NULL    |                |
| id_departamento | int         | YES  | MUL | NULL    |                |
+-----------------+-------------+------+-----+---------+----------------+
4 rows in set (0,00 sec)

mysql> 
UPDATE `escola`.`curso` SET `id_departamento` = '3' WHERE (`id` = '1');
UPDATE `escola`.`curso` SET `id_departamento` = '3' WHERE (`id` = '2');
UPDATE `escola`.`curso` SET `id_departamento` = '3' WHERE (`id` = '3');
UPDATE `escola`.`curso` SET `id_departamento` = '3' WHERE (`id` = '4');
UPDATE `escola`.`curso` SET `id_departamento` = '1' WHERE (`id` = '5');
UPDATE `escola`.`curso` SET `id_departamento` = '1' WHERE (`id` = '6');
UPDATE `escola`.`curso` SET `id_departamento` = '1' WHERE (`id` = '7');
UPDATE `escola`.`curso` SET `id_departamento` = '1' WHERE (`id` = '8');
UPDATE `escola`.`curso` SET `id_departamento` = '2' WHERE (`id` = '9');
UPDATE `escola`.`curso` SET `id_departamento` = '2' WHERE (`id` = '10');
UPDATE `escola`.`curso` SET `id_departamento` = '2' WHERE (`id` = '11');
UPDATE `escola`.`curso` SET `id_departamento` = '2' WHERE (`id` = '12');
UPDATE `escola`.`curso` SET `id_departamento` = '2' WHERE (`id` = '13');

select c.nome as curso, d.nome as departamento
from curso as c
inner join departamento as d
on c.id_departamento = d.id;

+----------------------------+-----------------------+
| curso                      | departamento          |
+----------------------------+-----------------------+
| Fisioterapia               | Ciências Biológicas   |
| Medicina                   | Ciências Biológicas   |
| Odontologia                | Ciências Biológicas   |
| Farmácia                   | Ciências Biológicas   |
| Psicologia                 | Ciências Humanas      |
| Direito                    | Ciências Humanas      |
| Administração              | Ciências Humanas      |
| Economia                   | Ciências Humanas      |
| Matemática                 | Ciências Exatas       |
| Física                     | Ciências Exatas       |
| Engenharia Elétrica        | Ciências Exatas       |
| Engenharia da Computação   | Ciências Exatas       |
| Ciência da Computação      | Ciências Exatas       |
+----------------------------+-----------------------+
13 rows in set (0,03 sec)

mysql> D




*/


